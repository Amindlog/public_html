#SXD20|20011|50505|70433|2024.06.21 19:32:44|admin_web_school|0|1|1|
#TA films`1`32768
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `films_id` int(11) NOT NULL AUTO_INCREMENT,
  `films_name` varchar(255) NOT NULL,
  `films_genre` varchar(45) NOT NULL COMMENT '		',
  `films_year` varchar(45) NOT NULL,
  PRIMARY KEY (`films_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(38,'Аватар3','Фентази','2024')	;
